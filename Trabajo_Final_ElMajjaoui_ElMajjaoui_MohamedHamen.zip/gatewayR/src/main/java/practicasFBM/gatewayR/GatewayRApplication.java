package practicasFBM.gatewayR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatewayRApplication {

	public static void main(String[] args) {
		SpringApplication.run(GatewayRApplication.class, args);
	}

}
