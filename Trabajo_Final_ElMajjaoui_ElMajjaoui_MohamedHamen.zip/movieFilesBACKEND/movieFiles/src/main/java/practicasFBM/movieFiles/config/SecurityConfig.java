package practicasFBM.movieFiles.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import practicasFBM.movieFiles.repository.IUserJPA;
import practicasFBM.movieFiles.model.Authority;

@Configuration
@EnableWebSecurity
public class SecurityConfig
{
    private final IUserJPA userRepo;

    public SecurityConfig(IUserJPA userRepo) {
        this.userRepo = userRepo;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(HttpMethod.GET, "/peliculas/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/actores/**").permitAll()
                        .requestMatchers("/peliculas/**").hasRole("ADMIN")
                        .requestMatchers("/actores/**"  ).hasRole("ADMIN")
                        // • Cualquier otra petición requiere estar autenticado
                        .anyRequest().authenticated()
                )
                // Form-login con el login-provided de Spring
                .httpBasic(Customizer.withDefaults())
                .logout(Customizer.withDefaults());

        return http.build();
    }

    @Bean
    public UserDetailsService userDetailsService() {
        return username -> userRepo
                .findByUsername(username)
                .map(u -> User.builder()
                        .username(u.getUsername())
                        .password(u.getPassword())
                        .disabled(!u.getEnabled())
                        .authorities(
                                u.getAuthorities()
                                        .stream()
                                        .map(Authority::getName)
                                        .toArray(String[]::new)
                        )
                        .build()
                )
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado"));
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }
}
