package practicasFBM.movieFiles.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import practicasFBM.movieFiles.model.Actor;
import practicasFBM.movieFiles.model.Pelicula;
import practicasFBM.movieFiles.services.IActorService;

import java.util.List;

@RestController
public class ActorController
{
    @Autowired
    IActorService actorService;

    @GetMapping("/actores")
    public List<Actor> getActores()
    {
        return actorService.getActores();
    }

    @GetMapping("/actores/{id}")
    public Actor getActorById(@PathVariable("id") Integer idActor)
    {
        return actorService.getActorById(idActor);
    }

    @GetMapping("/actores/participaciones/{id}")
    public List<Pelicula> getParticipaciones(@PathVariable("id") Integer idActor)
    {
        return actorService.getParticipaciones(idActor);
    }

    @DeleteMapping("/actores/eliminar/{id}")
    public void eliminarActor(@PathVariable("id") Integer idActor)
    {
        actorService.eliminarActor(idActor);
    }

    @PostMapping("/actores")
    public void guardarActor(@RequestBody Actor actorNuevo)
    {
        actorService.guardarActor(actorNuevo);
    }

    @PutMapping("/actores")
    public void actualizarActor(@RequestBody Actor actorActualizado)
    {
        actorService.actualizarActor(actorActualizado);
    }

}
