package practicasFBM.movieFiles.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import practicasFBM.movieFiles.model.Actor;
import practicasFBM.movieFiles.model.Pelicula;
import practicasFBM.movieFiles.services.IPeliculaService;

import java.io.IOException;
import java.util.List;

@RestController
public class PeliculaController
{
    @Autowired
    IPeliculaService peliculaService;

    @GetMapping("/peliculas")
    public Page<Pelicula> getPeliculasPaginadas(@RequestParam(defaultValue = "0") int page,
                                                @RequestParam(defaultValue = "8") int size) {
        return peliculaService.getPeliculasPaginadas(page, size);
    }

    @GetMapping("/peliculas/{id}")
    public Pelicula getPeliculaById(@PathVariable("id") Integer idPelicula)
    {
        return peliculaService.getPeliculaById(idPelicula);
    }

    @GetMapping("/peliculas/reparto/{id}")
    public List<Actor> getReparto(@PathVariable("id") Integer idPelicula)
    {
        return peliculaService.getReparto(idPelicula);
    }

    @GetMapping("/peliculas/titulo")
    public Page<Pelicula> getPeliculasByTitulo(@RequestParam("titulo") String titulo,
                                               @RequestParam(defaultValue = "0") int page,
                                               @RequestParam(defaultValue = "8") int size)
    {
        return peliculaService.getPeliculasByTitulo(titulo, page, size);
    }

    @GetMapping("/peliculas/genero")
    public Page<Pelicula> getPeliculasByGenero(@RequestParam("genero") String genero,
                                                               @RequestParam(defaultValue = "0") int page,
                                                               @RequestParam(defaultValue = "8") int size)
    {
        return peliculaService.getPeliculasByGenero(genero, page, size);
    }

    @GetMapping("/peliculas/nombreActor")
    public Page<Pelicula> getPeliculasByActor(@RequestParam("nombreActor") String nombreActor,
                                              @RequestParam(defaultValue = "0") int page,
                                              @RequestParam(defaultValue = "8") int size)
    {
        return peliculaService.getPeliculasByActor(nombreActor, page, size);
    }

    // Descargar portada
    @GetMapping("/peliculas/{id}/portada")
    public ResponseEntity<byte[]> getPortada(@PathVariable Integer id) throws IOException
    {
        byte[] data = peliculaService.obtenerPortada(id);
        return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(data);
    }

    // Subir portada
    @PostMapping(value = "/peliculas/{id}/portada", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Void> uploadPortada(@PathVariable Integer id,@RequestParam("file") MultipartFile file) throws IOException {
        peliculaService.guardarPortada(id, file);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/peliculas")
    public void guardarPelicula(@RequestBody Pelicula peliculaNueva)
    {
        peliculaService.guardarPelicula(peliculaNueva);
    }

    @PutMapping("/peliculas")
    public void actualizarPelicula(@RequestBody Pelicula peliculaActualizada)
    {
        peliculaService.actualizarPelicula(peliculaActualizada);
    }

    @DeleteMapping("/peliculas/eliminar/{id}")
    public void eliminarPelicula(@PathVariable("id") Integer idPelicula)
    {
        peliculaService.eliminarPelicula(idPelicula);
    }
}
