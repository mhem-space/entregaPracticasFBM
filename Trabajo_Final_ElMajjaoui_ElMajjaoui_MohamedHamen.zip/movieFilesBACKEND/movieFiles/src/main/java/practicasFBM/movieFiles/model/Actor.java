package practicasFBM.movieFiles.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "actor", schema = "moviesdb")
@JsonIgnoreProperties("peliculas")
public class Actor
{
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_actor")
    private Integer idActor;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "fecha_nacimiento")
    private LocalDate fechaNacimiento;
    @Basic
    @Column(name = "pais_nacimiento")
    private String paisNacimiento;

    @ManyToMany(mappedBy = "actors")
    @JsonIgnore
    private List<Pelicula> peliculas = new ArrayList<>();

    public List<Pelicula> getPeliculas()
    {
        return peliculas;
    }

    public void setPeliculas(List<Pelicula> reparto)
    {
        this.peliculas = reparto;
    }

    public Integer getIdActor()
    {
        return idActor;
    }

    public void setIdActor(Integer idActor)
    {
        this.idActor = idActor;
    }

    public String getNombre()
    {
        return nombre;
    }

    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }

    public LocalDate getFechaNacimiento()
    {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento)
    {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getPaisNacimiento()
    {
        return paisNacimiento;
    }

    public void setPaisNacimiento(String paisNacimiento)
    {
        this.paisNacimiento = paisNacimiento;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Actor that = (Actor) o;
        return Objects.equals(idActor, that.idActor) && Objects.equals(nombre, that.nombre) && Objects.equals(fechaNacimiento, that.fechaNacimiento) && Objects.equals(paisNacimiento, that.paisNacimiento);
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(idActor, nombre, fechaNacimiento, paisNacimiento);
    }
}
