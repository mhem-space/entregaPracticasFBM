package practicasFBM.movieFiles.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import practicasFBM.movieFiles.model.User;

import java.util.Optional;

public interface IUserJPA extends JpaRepository<User, Integer>
{
    // Para buscar por nombre de usuario (login)
    Optional<User> findByUsername(String username);
}
