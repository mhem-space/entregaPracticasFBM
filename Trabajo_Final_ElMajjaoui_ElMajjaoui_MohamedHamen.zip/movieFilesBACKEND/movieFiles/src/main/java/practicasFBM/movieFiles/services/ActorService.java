package practicasFBM.movieFiles.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import practicasFBM.movieFiles.model.Actor;
import practicasFBM.movieFiles.model.Pelicula;
import practicasFBM.movieFiles.repository.IActorRepository;

import java.util.List;

@Service
public class ActorService implements IActorService
{
    @Autowired
    IActorRepository actorRepository;

    @Override
    public Actor getActorById(Integer idActor)
    {
        return actorRepository.getActorById(idActor);
    }

    @Override
    public List<Pelicula> getParticipaciones(Integer idActor)
    {
        return actorRepository.getParticipaciones(idActor);
    }

    @Override
    public void eliminarActor(Integer idActor)
    {
        actorRepository.eliminarActor(idActor);
    }

    @Override
    public List<Actor> getActores()
    {
        return actorRepository.getActores();
    }

    @Override
    public void guardarActor(Actor actorNuevo)
    {
        actorRepository.guardarActor(actorNuevo);
    }

    @Override
    public void actualizarActor(Actor actorActualizado)
    {
        actorRepository.actualizarActor(actorActualizado);
    }
}
