package practicasFBM.movieFiles.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import practicasFBM.movieFiles.model.Actor;
import practicasFBM.movieFiles.model.Pelicula;
import practicasFBM.movieFiles.repository.IPeliculaRepository;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

@Service
public class PeliculaService implements IPeliculaService
{
    @Autowired
    IPeliculaRepository peliculaRepository;

    @Value("${file.upload-dir}")
    private String uploadDir;


    @Override
    public Pelicula getPeliculaById(Integer idPelicula)
    {
        return peliculaRepository.getPeliculaById(idPelicula);
    }

    @Override
    public List<Actor> getReparto(Integer idPelicula)
    {
        return peliculaRepository.getReparto(idPelicula);
    }

    @Override
    public void eliminarPelicula(Integer idPelicula)
    {
        peliculaRepository.eliminarPelicula(idPelicula);
    }

    //@Override
//    public List<Pelicula> getPeliculas()
//    {
//        return peliculaRepository.getPeliculas();
//    }

    @Override
    public Page<Pelicula> getPeliculasPaginadas(int page, int size) {
        return peliculaRepository.getPeliculasPaginadas(page, size);
    }
    @Override
    public Page<Pelicula> getPeliculasByTitulo(String titulo, int page, int size)
    {
        return peliculaRepository.getPeliculasByTitulo(titulo, page, size);
    }

    @Override
    public Page<Pelicula> getPeliculasByGenero(String genero, int page, int size)
    {
        return peliculaRepository.getPeliculasByGenero(genero, page, size);
    }

    @Override
    public Page<Pelicula> getPeliculasByActor(String nombreActor, int page, int size)
    {
        return peliculaRepository.getPeliculasByActor(nombreActor, page, size);
    }

    @Override
    public void guardarPelicula(Pelicula peliculaNueva)
    {
        if (peliculaNueva.getNombrePortada() == null || peliculaNueva.getNombrePortada().isEmpty()) {
            peliculaNueva.setNombrePortada("default.jpg"); // Asignar una portada por defecto si no se proporciona
        }
        peliculaRepository.guardarPelicula(peliculaNueva);
    }

    @Override
    public void actualizarPelicula(Pelicula peliculaActualizada)
    {
        peliculaRepository.actualizarPelicula(peliculaActualizada);
    }

    @Transactional
    public void guardarPortada(Integer id, MultipartFile file) throws IOException
    {
        Pelicula pelicula = peliculaRepository.getPeliculaById(id);

        // nombre = "{id}.{ext}"
        String ext = StringUtils.getFilenameExtension(file.getOriginalFilename());
        String nombre = file.getOriginalFilename();

        Path carpeta = Paths.get(uploadDir).toAbsolutePath().normalize();
        Files.createDirectories(carpeta);

        Path destino = carpeta.resolve(nombre);
        try (InputStream in = file.getInputStream()) {
            Files.copy(in, destino, StandardCopyOption.REPLACE_EXISTING);
        }

        pelicula.setNombrePortada(nombre);
        peliculaRepository.actualizarPelicula(pelicula);
    }

    @Transactional(readOnly=true)
    public byte[] obtenerPortada(Integer id) throws IOException {
        Pelicula pelicula = peliculaRepository.getPeliculaById(id);

        Path fichero = Paths.get(uploadDir).resolve(pelicula.getNombrePortada());
        return Files.readAllBytes(fichero);
    }
}
