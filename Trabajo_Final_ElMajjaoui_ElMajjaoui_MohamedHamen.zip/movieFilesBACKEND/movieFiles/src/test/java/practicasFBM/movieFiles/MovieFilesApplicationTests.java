package practicasFBM.movieFiles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieFilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
