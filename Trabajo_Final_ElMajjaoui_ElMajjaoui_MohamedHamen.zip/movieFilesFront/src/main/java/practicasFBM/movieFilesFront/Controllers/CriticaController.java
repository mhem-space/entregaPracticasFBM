package practicasFBM.movieFilesFront.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import practicasFBM.movieFilesFront.Model.Actor;
import practicasFBM.movieFilesFront.Model.Critica;
import practicasFBM.movieFilesFront.Paginator.PageRender;
import practicasFBM.movieFilesFront.Services.ICriticaService;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/criticas")
public class CriticaController
{
    @Autowired
    ICriticaService criticaService;

    @GetMapping("/gestion")
    public String gestionCriticas(Model model) {
        List<Critica> listadoCriticas = criticaService.getCriticas();

        model.addAttribute("listadoCriticas",listadoCriticas);

        return "critica/gestionCriticas";
    }

    @GetMapping("/add/{id}")
    public String agregarCritica(Model model, @PathVariable("id") Integer id)
    {
        model.addAttribute("titulo", "Nueva crítica");
        Critica criticaNueva = new Critica();
        model.addAttribute("criticaNueva",criticaNueva);
        model.addAttribute("idPelicula",id);
        return "critica/agregarCritica";
    }

    @PostMapping("/addCritica/{id}")
    public String agregarCritica(Model model, Critica nuevaCritica ,@PathVariable("id") Integer idPelicula, RedirectAttributes attributes)
    {
        criticaService.guardarCritica(nuevaCritica, idPelicula);
        model.addAttribute("titulo", "Nuevo actor");
        attributes.addFlashAttribute("msg", "Los datos de la nueva crítica han sido guardados!");
        return "redirect:/ver/"+idPelicula;
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarCritica(Model model, @PathVariable("id") Integer id,RedirectAttributes attributes) {
        criticaService.eliminarCritica(id);
        attributes.addFlashAttribute("msg", "Los datos de la crítica han sido eliminados!");
        return "redirect:/criticas/gestion";
    }
}
