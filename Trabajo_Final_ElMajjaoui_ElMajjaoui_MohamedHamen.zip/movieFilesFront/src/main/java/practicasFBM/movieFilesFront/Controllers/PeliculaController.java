package practicasFBM.movieFilesFront.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import practicasFBM.movieFilesFront.Model.Pelicula;
import practicasFBM.movieFilesFront.Paginator.PageRender;
import practicasFBM.movieFilesFront.Services.IPeliculaService;

import java.io.IOException;
import java.util.Optional;

@Controller
@RequestMapping("/peliculas")
public class PeliculaController
{
    @Autowired
    IPeliculaService peliculaService;

    @GetMapping("/gestion")
    public String gestionPeliculas(Model model, @RequestParam Optional<Integer> page) {

        Page<Pelicula> listadoPeliculas = peliculaService.getPeliculas(PageRequest.of(page.orElse(0), 8, Sort.Direction.ASC, "idPelicula"));
        PageRender<Pelicula> pageRender = new PageRender<Pelicula>("/peliculas/gestion", listadoPeliculas);

        model.addAttribute("listadoPeliculas",listadoPeliculas);
        model.addAttribute("page",pageRender);

        return "pelicula/gestionPeliculas";
    }

    @GetMapping("/add")
    public String agregarPelicula(Model model)
    {
        model.addAttribute("titulo", "Nueva pelicula");
        model.addAttribute("pelicula",new Pelicula());
        return "pelicula/agregarPelicula";
    }

    @PostMapping("/addPelicula")
    public String guardarPelicula(@ModelAttribute Pelicula pelicula,
                                  @RequestParam(value = "file", required = false) MultipartFile file,
                                  RedirectAttributes attrs) throws IOException
    {
        boolean esNuevo = (pelicula.getIdPelicula() == null);

        // 1) Crear o actualizar la entidad
        Pelicula saved;
        if (esNuevo) {
            saved = peliculaService.crearPelicula(pelicula);
        } else {
            peliculaService.guardarPelicula(pelicula);
            saved = pelicula;
        }

        // 2) Subir portada si viene fichero
        if (file != null && !file.isEmpty()) {
            peliculaService.subirPortada(saved.getIdPelicula(), file);
        }

        attrs.addFlashAttribute("msg",
                esNuevo
                        ? "¡Película creada con éxito!"
                        : "¡Película actualizada con éxito!");
        return "redirect:/peliculas/gestion";
    }

    @GetMapping("/editar/{id}")
    public String editarPelicula(Model model, @PathVariable("id") Integer id) {
        Pelicula pelicula = peliculaService.getPeliculaById(id);
        pelicula.setActors(peliculaService.getReparto(id));
        model.addAttribute("titulo", "Editar película");
        model.addAttribute("pelicula", pelicula);
        return "pelicula/editarPelicula";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarPelicula(Model model, @PathVariable("id") Integer id,RedirectAttributes attributes) {
        peliculaService.eliminarPelicula(id);
        attributes.addFlashAttribute("msg", "Los datos de la pelicula han sido eliminados!");
        return "redirect:/peliculas/gestion";
    }

}
