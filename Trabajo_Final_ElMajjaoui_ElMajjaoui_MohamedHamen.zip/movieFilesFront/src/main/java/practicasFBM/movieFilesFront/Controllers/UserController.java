package practicasFBM.movieFilesFront.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import practicasFBM.movieFilesFront.Model.Critica;
import practicasFBM.movieFilesFront.Model.Pelicula;
import practicasFBM.movieFilesFront.Model.User;
import practicasFBM.movieFilesFront.Paginator.PageRender;
import practicasFBM.movieFilesFront.Services.IUserService;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/usuarios")
public class UserController
{
    @Autowired
    IUserService userService;

    @GetMapping("/gestion")
    public String gestionUsuarios(Model model, @RequestParam Optional<Integer> page) {

        Page<User> listadoUsuarios = userService.getUsuarios(PageRequest.of(page.orElse(0), 8, Sort.Direction.ASC, "id"));
        PageRender<User> pageRender = new PageRender<User>("/usuarios/gestion", listadoUsuarios);

        model.addAttribute("listadoUsuarios",listadoUsuarios);
        model.addAttribute("page",pageRender);

        return "user/gestionUsuarios";
    }

    @GetMapping("/baja/{id}")
    public String darBajaUsuario(Model model, @PathVariable("id") Integer id, RedirectAttributes attributes) {
        userService.darBajaUsuario(id);
        attributes.addFlashAttribute("msg", "El usuario ha sido dado de baja!");
        return "redirect:/usuarios/gestion";
    }
}
