package practicasFBM.movieFilesFront.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;

@Entity
@Table(name = "critica")
public class Critica
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_critica", nullable = false)
    private Integer id;

    @Column(name = "id_pelicula", nullable = false)
    private Integer peliculaId;

    @Lob
    @Column(name = "valoracion")
    private String valoracion;

    @Column(name = "nota")
    private Integer nota;

    @Column(name = "fecha")
    private LocalDate fecha;

    @Column(name = "user_id", nullable = false)
    private Integer userId;

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getIdPelicula()
    {
        return peliculaId;
    }

    public void setIdPelicula(Integer idPelicula)
    {
        this.peliculaId = idPelicula;
    }

    public String getValoracion()
    {
        return valoracion;
    }

    public void setValoracion(String valoracion)
    {
        this.valoracion = valoracion;
    }

    public Integer getNota()
    {
        return nota;
    }

    public void setNota(Integer nota)
    {
        this.nota = nota;
    }

    public LocalDate getFecha()
    {
        return fecha;
    }

    public void setFecha(LocalDate fecha)
    {
        this.fecha = fecha;
    }

    public Integer getIdUser()
    {
        return userId;
    }

    public void setIdUser(Integer userId)
    {
        this.userId = userId;
    }

}