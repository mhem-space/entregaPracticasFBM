package practicasFBM.movieFilesFront.Model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "pelicula", schema = "moviesdb")
public class Pelicula
{
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_pelicula")
    private Integer idPelicula;
    @Basic
    @Column(name = "titulo")
    private String titulo;
    @Basic
    @Column(name = "anno")
    private Integer anno;
    @Basic
    @Column(name = "duracion")
    private Integer duracion;
    @Basic
    @Column(name = "pais")
    private String pais;
    @Basic
    @Column(name = "direccion")
    private String direccion;
    @Basic
    @Column(name = "genero")
    private String genero;
    @Basic
    @Column(name = "sinopsis")
    private String sinopsis;
    @Basic
    @Column(name = "nombre_portada")
    private String nombrePortada;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "reparto",
            joinColumns = @JoinColumn(name = "pelicula_id_pelicula"),
            inverseJoinColumns = @JoinColumn(name = "actor_id_actor"))
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<Actor> actors = new ArrayList<>();

    @Transient
    private List<Integer> listaActores = new ArrayList<>();


    @Transient
    private String portadaBase64;

    public List<Integer> getListaActores()
    {
        return listaActores;
    }

    public void setListaActores(List<Integer> listaActores)
    {
        this.listaActores = listaActores;
    }

    public List<Actor> getActors()
    {
        return actors;
    }

    public void setActors(List<Actor> actors)
    {
        this.actors = actors;
    }

    public Integer getIdPelicula()
    {
        return idPelicula;
    }

    public void setIdPelicula(Integer idPelicula)
    {
        this.idPelicula = idPelicula;
    }

    public String getTitulo()
    {
        return titulo;
    }

    public void setTitulo(String titulo)
    {
        this.titulo = titulo;
    }

    public Integer getAnno()
    {
        return anno;
    }

    public void setAnno(Integer anno)
    {
        this.anno = anno;
    }

    public Integer getDuracion()
    {
        return duracion;
    }

    public void setDuracion(Integer duracion)
    {
        this.duracion = duracion;
    }

    public String getPais()
    {
        return pais;
    }

    public void setPais(String pais)
    {
        this.pais = pais;
    }

    public String getDireccion()
    {
        return direccion;
    }

    public void setDireccion(String direccion)
    {
        this.direccion = direccion;
    }

    public String getGenero()
    {
        return genero;
    }

    public void setGenero(String genero)
    {
        this.genero = genero;
    }

    public String getSinopsis()
    {
        return sinopsis;
    }

    public void setSinopsis(String sinopsis)
    {
        this.sinopsis = sinopsis;
    }

    public String getNombrePortada()
    {
        return nombrePortada;
    }

    public void setNombrePortada(String portada)
    {
        this.nombrePortada = portada;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pelicula that = (Pelicula) o;
        return Objects.equals(idPelicula, that.idPelicula) && Objects.equals(titulo, that.titulo) && Objects.equals(anno, that.anno)
                && Objects.equals(duracion, that.duracion) && Objects.equals(pais, that.pais) && Objects.equals(direccion, that.direccion)
                && Objects.equals(genero, that.genero) && Objects.equals(sinopsis, that.sinopsis) && Objects.equals(nombrePortada, that.nombrePortada);
    }

    @Override
    public int hashCode()
    {
        int result = Objects.hash(idPelicula, titulo, anno, duracion, pais, direccion, genero, sinopsis);
        result = 31 * result + Objects.hashCode(nombrePortada);
        return result;
    }
}
