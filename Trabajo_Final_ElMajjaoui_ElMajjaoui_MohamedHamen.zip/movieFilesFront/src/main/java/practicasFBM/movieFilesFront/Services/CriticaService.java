package practicasFBM.movieFilesFront.Services;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import practicasFBM.movieFilesFront.Model.Actor;
import practicasFBM.movieFilesFront.Model.Critica;

import java.util.Arrays;
import java.util.List;

@Service
public class CriticaService implements ICriticaService
{
    @Autowired
    private RestTemplateBuilder restBuilder;


    String url = "http://localhost:8090/api/criticas/criticas";

    @Override
    public String getMedia(Integer peliculaId)
    {
        ServletRequestAttributes attr =
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpSession session = attr.getRequest().getSession(false);

        String user = (String) session.getAttribute("BASIC_AUTH_USERNAME");
        String pass = (String) session.getAttribute("BASIC_AUTH_PASSWORD");

        RestTemplate template = restBuilder
                .basicAuthentication(user, pass)
                .build();
        String urlMedia = url+"/pelicula/" + peliculaId + "/media";
        return template.getForObject(urlMedia, String.class);
    }

    @Override
    public List<Critica> getCriticas()
    {
        ServletRequestAttributes attr =
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpSession session = attr.getRequest().getSession(false);

        String user = (String) session.getAttribute("BASIC_AUTH_USERNAME");
        String pass = (String) session.getAttribute("BASIC_AUTH_PASSWORD");

        RestTemplate template = restBuilder
                .basicAuthentication(user, pass)
                .build();

        Critica[] criticas = template.getForObject(url, Critica[].class);
        return criticas != null ? Arrays.asList(criticas) : null;
    }

    @Override
    public List<Critica> getCriticasByPelicula(Integer peliculaId)
    {
        ServletRequestAttributes attr =
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpSession session = attr.getRequest().getSession(false);

        String user = (String) session.getAttribute("BASIC_AUTH_USERNAME");
        String pass = (String) session.getAttribute("BASIC_AUTH_PASSWORD");

        RestTemplate template = restBuilder
                .basicAuthentication(user, pass)
                .build();

        String urlCriticas = url+"/pelicula/" + peliculaId;
        Critica[] criticas = template.getForObject(urlCriticas, Critica[].class);

        return criticas != null ? Arrays.asList(criticas) : null;
    }

    @Override
    public void guardarCritica(Critica nuevaCritica, Integer idPelicula)
    {
        ServletRequestAttributes attr =
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpSession session = attr.getRequest().getSession(false);

        String user = (String) session.getAttribute("BASIC_AUTH_USERNAME");
        String pass = (String) session.getAttribute("BASIC_AUTH_PASSWORD");

        RestTemplate template = restBuilder
                .basicAuthentication(user, pass)
                .build();

        String urlNuevaCritica = url + "/pelicula/" + idPelicula;
        var criticaDTO = new Object() {
            public final String valoracion = nuevaCritica.getValoracion();
            public final Integer nota = nuevaCritica.getNota();
        };
        template.postForObject(urlNuevaCritica,criticaDTO, String.class);
    }

    @Override
    public void eliminarCritica(Integer idCritica)
    {
        ServletRequestAttributes attr =
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpSession session = attr.getRequest().getSession(false);

        String user = (String) session.getAttribute("BASIC_AUTH_USERNAME");
        String pass = (String) session.getAttribute("BASIC_AUTH_PASSWORD");

        RestTemplate template = restBuilder
                .basicAuthentication(user, pass)
                .build();

        template.delete(url + "/" + idCritica);
    }
}
