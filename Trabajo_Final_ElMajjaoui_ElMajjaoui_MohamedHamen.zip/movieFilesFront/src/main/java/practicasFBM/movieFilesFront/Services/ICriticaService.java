package practicasFBM.movieFilesFront.Services;

import practicasFBM.movieFilesFront.Model.Critica;

import java.util.List;

public interface ICriticaService
{
    String getMedia(Integer peliculaId);
    List<Critica> getCriticas();
    List<Critica> getCriticasByPelicula(Integer peliculaId);
    void guardarCritica(Critica nuevaCritica,Integer idPelicula);
    void eliminarCritica(Integer idCritica);
}
