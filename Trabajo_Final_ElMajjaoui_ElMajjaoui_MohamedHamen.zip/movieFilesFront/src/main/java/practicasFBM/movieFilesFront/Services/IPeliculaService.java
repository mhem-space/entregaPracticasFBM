package practicasFBM.movieFilesFront.Services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import practicasFBM.movieFilesFront.Model.Actor;
import practicasFBM.movieFilesFront.Model.Pelicula;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface IPeliculaService
{
    Pelicula getPeliculaById(Integer idPelicula);

    List<Actor> getReparto(Integer idPelicula);

    void eliminarPelicula(Integer idPelicula);

    Page<Pelicula> getPeliculas(Pageable pageable);

    Page<Pelicula> getPeliculasByTitulo(Pageable pageable, String titulo);

    Page<Pelicula> getPeliculasByGenero(Pageable pageable, String genero);

    Page<Pelicula> getPeliculasByActor(Pageable pageable, String nombreActor);

    void guardarPelicula(Pelicula peliculaNueva);

    Pelicula crearPelicula(Pelicula pelicula);

    void subirPortada(Integer id, MultipartFile file) throws IOException;

}
