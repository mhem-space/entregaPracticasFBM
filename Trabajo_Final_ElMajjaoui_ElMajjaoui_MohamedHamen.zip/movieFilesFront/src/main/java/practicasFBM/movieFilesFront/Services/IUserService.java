package practicasFBM.movieFilesFront.Services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import practicasFBM.movieFilesFront.Model.User;

public interface IUserService
{
    Page<User> getUsuarios(Pageable pageable);
    void darBajaUsuario(Integer idUsuario);
}
