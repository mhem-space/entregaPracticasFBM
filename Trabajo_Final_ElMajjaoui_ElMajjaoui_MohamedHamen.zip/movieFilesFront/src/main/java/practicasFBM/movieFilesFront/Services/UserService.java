package practicasFBM.movieFilesFront.Services;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriComponentsBuilder;
import practicasFBM.movieFilesFront.Model.Critica;
import practicasFBM.movieFilesFront.Model.PageResponse;
import practicasFBM.movieFilesFront.Model.Pelicula;
import practicasFBM.movieFilesFront.Model.User;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class UserService implements IUserService
{
    @Autowired
    private RestTemplateBuilder restBuilder;

    String url = "http://localhost:8090/api/criticas/users";

    @Override
    public Page<User> getUsuarios(Pageable pageable)
    {
        ServletRequestAttributes attr =
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpSession session = attr.getRequest().getSession(false);

        String user = (String) session.getAttribute("BASIC_AUTH_USERNAME");
        String pass = (String) session.getAttribute("BASIC_AUTH_PASSWORD");

        RestTemplate template = restBuilder
                .basicAuthentication(user, pass)
                .build();

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url)
                .queryParam("page", pageable.getPageNumber())
                .queryParam("size", pageable.getPageSize());
        URI uri = builder.build().toUri();

        ResponseEntity<PageResponse<User>> response = template.exchange(
                uri,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<PageResponse<User>>() {}
        );
        PageResponse<User> pageResponse = response.getBody();
        List<User> listadoUsuarios = pageResponse != null ? pageResponse.getContent() : Collections.emptyList();

        // Si necesitas devolver un Page<Pelicula>, puedes usar PageImpl
        return new PageImpl<>(listadoUsuarios, pageable, pageResponse != null ? pageResponse.getTotalElements() : 0);
    }

    @Override
    public void darBajaUsuario(Integer idUsuario)
    {
        ServletRequestAttributes attr =
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpSession session = attr.getRequest().getSession(false);

        String user = (String) session.getAttribute("BASIC_AUTH_USERNAME");
        String pass = (String) session.getAttribute("BASIC_AUTH_PASSWORD");

        RestTemplate template = restBuilder
                .basicAuthentication(user, pass)
                .build();

        template.getForObject(url + "/" + idUsuario+"/disable", Void.class);
    }
}
