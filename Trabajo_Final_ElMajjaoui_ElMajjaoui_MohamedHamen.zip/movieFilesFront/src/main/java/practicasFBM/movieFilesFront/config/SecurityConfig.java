package practicasFBM.movieFilesFront.config;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import practicasFBM.movieFilesFront.repository.IUserJPA;
import practicasFBM.movieFilesFront.Model.Authority;

import java.io.IOException;

@Configuration
@EnableWebSecurity
public class SecurityConfig
{
    private final IUserJPA userRepo;

    public SecurityConfig(IUserJPA userRepo) {
        this.userRepo = userRepo;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        // Recursos estáticos (css, imágenes, js) siempre públicos
                        .requestMatchers(
                                "/css/**",
                                "/images/**",
                                "/js/**",
                                "/webjars/**"
                        ).permitAll()
                        .requestMatchers(HttpMethod.GET, "/peliculas/gestion", "/peliculas/add/**", "/peliculas/editar/**", "/peliculas/eliminar/**")
                        .hasRole("ADMIN")
                        .requestMatchers(HttpMethod.GET, "/actores/gestion", "/actores/add/**", "/actores/editar/**", "/actores/eliminar/**")
                        .hasRole("ADMIN")
                        .requestMatchers("/peliculas/**").hasRole("ADMIN")
                        .requestMatchers("/actores/**").hasRole("ADMIN")
                        // Cualquier otra petición requiere estar autenticado
                        .anyRequest().authenticated()
                )
                // Form-login con el login-provided de Spring
                .formLogin(form -> form
                        .successHandler(this::onLoginSuccess)   // ← interceptamos
                )
                .logout(Customizer.withDefaults());

        return http.build();
    }

    private void onLoginSuccess(
            HttpServletRequest request,
            HttpServletResponse response,
            Authentication authentication
    ) throws IOException, ServletException
    {
        // 1) Leemos usuario y PASS del request
        String username = authentication.getName();
        String rawPassword = request.getParameter("password");

        // 2) Guardamos ambos en sesión
        HttpSession session = request.getSession();
        session.setAttribute("BASIC_AUTH_USERNAME", username);
        session.setAttribute("BASIC_AUTH_PASSWORD", rawPassword);

        // 3) Continuamos con el flujo normal de redirect
        //    puedes mandar al defaultSuccessUrl, o usar:
        response.sendRedirect(request.getContextPath() + "/");
    }

    @Bean
    public UserDetailsService userDetailsService() {
        return username -> userRepo
                .findByUsername(username)
                .map(u -> User.builder()
                        .username(u.getUsername())
                        .password(u.getPassword())
                        .disabled(!u.getEnabled())
                        .authorities(
                                u.getAuthorities()
                                        .stream()
                                        .map(Authority::getName)
                                        .toArray(String[]::new)
                        )
                        .build()
                )
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado"));
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }
}
