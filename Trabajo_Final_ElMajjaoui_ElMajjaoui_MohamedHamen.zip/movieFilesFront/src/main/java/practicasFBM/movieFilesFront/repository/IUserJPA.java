package practicasFBM.movieFilesFront.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import practicasFBM.movieFilesFront.Model.User;

import java.util.Optional;

public interface IUserJPA extends JpaRepository<User, Integer>
{
    // Para buscar por nombre de usuario (login)
    Optional<User> findByUsername(String username);
}
