package practicasFBM.movieFilesFront;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieFilesFrontApplicationTests {

	@Test
	void contextLoads() {
	}

}
