package practicasFBM.movieReviews.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import practicasFBM.movieReviews.model.Critica;
import practicasFBM.movieReviews.model.CriticaDTO;
import practicasFBM.movieReviews.services.ICriticaService;
import practicasFBM.movieReviews.services.IUserService;

import java.util.List;

@RestController
@RequestMapping("/criticas")
public class CriticaController
{
    @Autowired
    private ICriticaService criticaService;

    @Autowired
    private IUserService userService;

    /** Listar todas las críticas */
    @GetMapping()
    public List<Critica> getCriticas() {
        return criticaService.getCriticas();
    }

    /** Listar críticas de una película */
    @GetMapping("/pelicula/{id}")
    public List<Critica> getCriticasByPelicula(@PathVariable("id") Integer peliculaId) {
        return criticaService.getByPelicula(peliculaId);
    }

    /** Listar críticas de un usuario (admin) */
    @GetMapping("/user/{id}")
    public List<Critica> getCriticasByUser(@PathVariable("id") Integer userId) {
        return criticaService.getByUser(userId);
    }

    /** Devuelve la nota media de una película (o mensaje si no hay críticas) */
    @GetMapping("/pelicula/{id}/media")
    public ResponseEntity<String> getMedia(@PathVariable Integer id) {
        List<Critica> lista = criticaService.getByPelicula(id);
        if (lista.isEmpty()) {
            return ResponseEntity.ok("No tiene críticas");
        }
        double media = lista.stream()
                .mapToInt(Critica::getNota)
                .average()
                .orElse(0);
        // Dar formato con un decimal, por ejemplo
        String texto = String.format("%.1f", media);
        return ResponseEntity.ok(texto);
    }

    /** Crear nueva crítica (USER o ADMIN) */
    @PostMapping("/pelicula/{peliculaId}")
    @ResponseStatus(HttpStatus.CREATED)
    public Critica addCritica(
            @PathVariable Integer peliculaId,
            @RequestBody CriticaDTO dto,
            @AuthenticationPrincipal UserDetails principal
    ) {
        return criticaService.publishCritica(principal.getUsername(),dto,peliculaId);
    }

    /** Eliminar crítica por ID (solo ADMIN) */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteCritica(@PathVariable Integer id) {
        Critica c = criticaService.getById(id);
        if (c == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Crítica no encontrada");
        }
        criticaService.delete(id);
    }
}
