package practicasFBM.movieReviews.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import practicasFBM.movieReviews.model.User;
import practicasFBM.movieReviews.services.IUserService;

@RestController
@RequestMapping("/users")
public class UserController
{
    @Autowired
    private IUserService userService;

    /** 1. Listar usuarios paginados (solo ADMIN) */
    @GetMapping
    public Page<User> listUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "8") int size
    ) {
        return userService.getPage(page, size);
    }

    /** 2. Obtener un usuario por ID (solo ADMIN) */
    @GetMapping("/{id}")
    public User getUserById(@PathVariable Integer id) {
        User u = userService.getById(id);
        if (u == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado");
        }
        return u;
    }

    /** 3. Perfil del propio usuario autenticado */
    @GetMapping("/me")
    public User getOwnProfile(@AuthenticationPrincipal UserDetails principal) {
        // principal.getUsername() devuelve el username
        User u = userService.getByUsername(principal.getUsername());
        if (u == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado");
        }
        return u;
    }

    /** 4. Crear nuevo usuario (registro) – abierto */
    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public User register(@RequestBody User newUser) {
        // Aquí podrías validar que no exista ya el username
        return userService.createOrUpdate(newUser);
    }

    /** 5. Actualizar usuario (solo ADMIN) */
    @PutMapping("/{id}")
    public User updateUser(
            @PathVariable Integer id,
            @RequestBody User updated
    ) {
        User existing = userService.getById(id);
        if (existing == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado");
        }
        // Copiar campos permitidos
        existing.setUsername(updated.getUsername());
        existing.setEnabled(updated.getEnabled());
        existing.setPassword(updated.getPassword());
        // Si gestionas roles aquí actualizar authorities…
        return userService.createOrUpdate(existing);
    }

    /** Desactivar usuario (dar de baja) – solo ADMIN */
    @GetMapping("/{id}/disable")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void disableUser(@PathVariable Integer id) {
        User u = userService.getById(id);
        if (u == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado");
        }
        u.setEnabled(false);
        userService.createOrUpdate(u);
    }
}
