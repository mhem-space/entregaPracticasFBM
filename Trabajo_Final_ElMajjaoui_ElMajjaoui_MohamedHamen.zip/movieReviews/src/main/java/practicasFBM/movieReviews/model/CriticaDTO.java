package practicasFBM.movieReviews.model;

public class CriticaDTO
{
    private String valoracion;
    private Integer nota;

    public CriticaDTO(String valoracion, Integer nota)
    {
        this.valoracion = valoracion;
        this.nota = nota;
    }

    public String getValoracion()
    {
        return valoracion;
    }

    public void setValoracion(String valoracion)
    {
        this.valoracion = valoracion;
    }

    public Integer getNota()
    {
        return nota;
    }

    public void setNota(Integer nota)
    {
        this.nota = nota;
    }
}
