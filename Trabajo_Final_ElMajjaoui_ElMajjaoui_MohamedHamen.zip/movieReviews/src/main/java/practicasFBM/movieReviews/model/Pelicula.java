package practicasFBM.movieReviews.model;

import jakarta.persistence.*;

@Entity
@Table(name = "pelicula")
public class Pelicula
{
    @Id
    @Column(name = "id_pelicula", nullable = false)
    private Integer id;

    @Lob
    @Column(name = "titulo", nullable = false)
    private String titulo;

    @Column(name = "anno", nullable = false)
    private Integer anno;

    @Column(name = "duracion", nullable = false)
    private Integer duracion;

    @Column(name = "pais", nullable = false, length = 60)
    private String pais;

    @Column(name = "direccion", nullable = false, length = 200)
    private String direccion;

    @Column(name = "genero", nullable = false, length = 50)
    private String genero;

    @Lob
    @Column(name = "sinopsis", nullable = false)
    private String sinopsis;

    @Column(name = "nombre_portada", nullable = false)
    private String nombrePortada;

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getTitulo()
    {
        return titulo;
    }

    public void setTitulo(String titulo)
    {
        this.titulo = titulo;
    }

    public Integer getAnno()
    {
        return anno;
    }

    public void setAnno(Integer anno)
    {
        this.anno = anno;
    }

    public Integer getDuracion()
    {
        return duracion;
    }

    public void setDuracion(Integer duracion)
    {
        this.duracion = duracion;
    }

    public String getPais()
    {
        return pais;
    }

    public void setPais(String pais)
    {
        this.pais = pais;
    }

    public String getDireccion()
    {
        return direccion;
    }

    public void setDireccion(String direccion)
    {
        this.direccion = direccion;
    }

    public String getGenero()
    {
        return genero;
    }

    public void setGenero(String genero)
    {
        this.genero = genero;
    }

    public String getSinopsis()
    {
        return sinopsis;
    }

    public void setSinopsis(String sinopsis)
    {
        this.sinopsis = sinopsis;
    }

    public String getNombrePortada()
    {
        return nombrePortada;
    }

    public void setNombrePortada(String nombrePortada)
    {
        this.nombrePortada = nombrePortada;
    }

}