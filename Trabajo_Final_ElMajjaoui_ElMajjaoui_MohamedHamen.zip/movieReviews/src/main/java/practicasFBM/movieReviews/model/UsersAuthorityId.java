package practicasFBM.movieReviews.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import org.hibernate.Hibernate;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class UsersAuthorityId implements Serializable
{
    private static final long serialVersionUID = 6626707428836559581L;
    @Column(name = "user_id", nullable = false)
    private Integer userId;

    @Column(name = "authority_id", nullable = false)
    private Integer authorityId;

    public Integer getUserId()
    {
        return userId;
    }

    public void setUserId(Integer userId)
    {
        this.userId = userId;
    }

    public Integer getAuthorityId()
    {
        return authorityId;
    }

    public void setAuthorityId(Integer authorityId)
    {
        this.authorityId = authorityId;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        UsersAuthorityId entity = (UsersAuthorityId) o;
        return Objects.equals(this.authorityId, entity.authorityId) &&
                Objects.equals(this.userId, entity.userId);
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(authorityId, userId);
    }

}