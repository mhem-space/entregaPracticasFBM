package practicasFBM.movieReviews.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import practicasFBM.movieReviews.model.Authority;

import java.util.List;
import java.util.Optional;

@Repository
public class AuthorityRepository implements IAuthorityRepository
{
    @Autowired
    private IAuthorityJPA authorityJPA;

    @Override
    public Authority getById(Integer id) {
        Optional<Authority> opt = authorityJPA.findById(id);
        return opt.orElse(null);
    }

    @Override
    public Authority getByName(String name) {
        return authorityJPA.findByName(name).orElse(null);
    }

    @Override
    public List<Authority> getAllAuthorities() {
        return authorityJPA.findAll();
    }

    @Override
    public Page<Authority> getAuthoritiesPage(int page, int size) {
        return authorityJPA.findAll(PageRequest.of(page, size));
    }

    @Override
    public void saveAuthority(Authority authority) {
        authorityJPA.save(authority);
    }

    @Override
    public void deleteAuthority(Integer id) {
        authorityJPA.deleteById(id);
    }
}
