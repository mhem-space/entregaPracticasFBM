package practicasFBM.movieReviews.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import practicasFBM.movieReviews.model.Critica;

import java.util.List;
import java.util.Optional;

@Repository
public class CriticaRepository implements ICriticaRepository
{
    @Autowired
    private ICriticaJPA criticaJPA;

    @Override
    public Critica getById(Integer id) {
        Optional<Critica> opt = criticaJPA.findById(id);
        return opt.orElse(null);
    }

    @Override
    public List<Critica> getCriticas() {
        return criticaJPA.findAll();
    }

    @Override
    public List<Critica> getByPelicula(Integer peliculaId) {
        return criticaJPA.findByPeliculaId(peliculaId);
    }

    @Override
    public List<Critica> getByUser(Integer userId) {
        return criticaJPA.findByUserId(userId);
    }

    @Override
    public Critica guardarCritica(Critica c) {
        return criticaJPA.save(c);
    }

    @Override
    public void deleteById(Integer id) {
        criticaJPA.deleteById(id);
    }
}
