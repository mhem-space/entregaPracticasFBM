package practicasFBM.movieReviews.repository;

import org.springframework.data.domain.Page;
import practicasFBM.movieReviews.model.Authority;

import java.util.List;

public interface IAuthorityRepository
{
    Authority getById(Integer id);
    Authority getByName(String name);
    List<Authority> getAllAuthorities();
    Page<Authority> getAuthoritiesPage(int page, int size);
    void saveAuthority(Authority authority);
    void deleteAuthority(Integer id);
}
