package practicasFBM.movieReviews.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import practicasFBM.movieReviews.model.Critica;

import java.util.List;

public interface ICriticaJPA extends JpaRepository<Critica, Integer>
{
    // Encuentra todas las críticas de una película
    List<Critica> findByPeliculaId(Integer peliculaId);

    // Encuentra todas las críticas de un usuario
    List<Critica> findByUserId(Integer userId);
}
