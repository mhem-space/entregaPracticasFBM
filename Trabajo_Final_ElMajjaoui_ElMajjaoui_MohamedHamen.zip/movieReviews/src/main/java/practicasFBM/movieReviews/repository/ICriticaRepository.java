package practicasFBM.movieReviews.repository;

import practicasFBM.movieReviews.model.Critica;

import java.util.List;

public interface ICriticaRepository
{
    Critica getById(Integer id);
    List<Critica> getCriticas();
    List<Critica> getByPelicula(Integer peliculaId);
    List<Critica> getByUser(Integer userId);
    Critica guardarCritica(Critica c);
    void deleteById(Integer id);
}
