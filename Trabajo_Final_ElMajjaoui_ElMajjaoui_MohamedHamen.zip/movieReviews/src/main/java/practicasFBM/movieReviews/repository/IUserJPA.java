package practicasFBM.movieReviews.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import practicasFBM.movieReviews.model.User;

import java.util.Optional;

public interface IUserJPA extends JpaRepository<User, Integer>
{
    // Para buscar por nombre de usuario (login)
    Optional<User> findByUsername(String username);
}
