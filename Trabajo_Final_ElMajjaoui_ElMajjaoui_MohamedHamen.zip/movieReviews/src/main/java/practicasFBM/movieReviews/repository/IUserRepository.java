package practicasFBM.movieReviews.repository;

import org.springframework.data.domain.Page;
import practicasFBM.movieReviews.model.User;

import java.util.List;

public interface IUserRepository
{
    User getUserById(Integer id);
    User getUserByUsername(String username);
    List<User> getAllUsers();
    Page<User> getUsersPage(int page, int size);
    void saveUser(User u);
    void deleteUser(Integer id);
}
