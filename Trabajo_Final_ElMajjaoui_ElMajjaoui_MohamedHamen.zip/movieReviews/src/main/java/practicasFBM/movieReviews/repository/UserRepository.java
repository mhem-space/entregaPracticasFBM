package practicasFBM.movieReviews.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Repository;
import practicasFBM.movieReviews.model.User;

import java.util.List;
import java.util.Optional;

@Repository
public class UserRepository implements IUserRepository
{
    @Autowired
    private IUserJPA userJPA;

    @Override
    public User getUserById(Integer id) {
        Optional<User> opt = userJPA.findById(id);
        return opt.orElse(null);
    }

    @Override
    public User getUserByUsername(String username) {
        return userJPA.findByUsername(username).orElse(null);
    }

    @Override
    public List<User> getAllUsers() {
        return userJPA.findAll();
    }

    @Override
    public Page<User> getUsersPage(int page, int size) {
        return userJPA.findAll(PageRequest.of(page, size));
    }

    @Override
    public void saveUser(User u) {
        userJPA.save(u);
    }

    @Override
    public void deleteUser(Integer id) {
        userJPA.deleteById(id);
    }
}
