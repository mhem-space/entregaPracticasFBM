package practicasFBM.movieReviews.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;
import practicasFBM.movieReviews.model.Critica;
import practicasFBM.movieReviews.model.CriticaDTO;
import practicasFBM.movieReviews.model.Pelicula;
import practicasFBM.movieReviews.model.User;
import practicasFBM.movieReviews.repository.ICriticaRepository;

import java.time.LocalDate;
import java.util.List;

@Service
public class CriticaService implements ICriticaService
{
    @Autowired
    RestTemplate restTemplate;
    @Autowired
    private IUserService userService;
    @Autowired
    private ICriticaRepository repo;

    String url = "http://localhost:8090/api/peliculas/peliculas";

    @Override
    public Critica getById(Integer id) {
        return repo.getById(id);
    }

    @Override
    public List<Critica> getCriticas() {
        return repo.getCriticas();
    }

    @Override
    public List<Critica> getByPelicula(Integer peliculaId) {
        return repo.getByPelicula(peliculaId);
    }

    @Override
    public List<Critica> getByUser(Integer userId) {
        return repo.getByUser(userId);
    }

    public Critica publishCritica(String username, CriticaDTO dto, Integer peliculaId) {
        // 1) Usuario autenticado
        User user = userService.getByUsername(username);
        if (user == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado");
        }

        // 2) Petición al microservicio de películas y actores
        Pelicula pelicula = restTemplate.getForObject(
                url + "/" + peliculaId,
                Pelicula.class
        );
        if (pelicula == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Película no encontrada");
        } else if (pelicula.getId() == null) {
            pelicula.setId(peliculaId); // Asegurarse de que la película tiene un ID
        }

        // 3) Montar la entidad Critica
        Critica nueva = new Critica();
        nueva.setUserId(user.getId());
        nueva.setIdPelicula(peliculaId);
        nueva.setValoracion(dto.getValoracion());
        nueva.setNota(dto.getNota());
        nueva.setFecha(LocalDate.now());

        // 4) Guardar
        return repo.guardarCritica(nueva);
    }

    @Override
    public void delete(Integer id) {
        repo.deleteById(id);
    }
}
