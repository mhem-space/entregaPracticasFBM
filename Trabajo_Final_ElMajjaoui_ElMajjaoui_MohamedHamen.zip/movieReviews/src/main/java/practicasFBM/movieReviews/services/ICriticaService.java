package practicasFBM.movieReviews.services;

import practicasFBM.movieReviews.model.Critica;
import practicasFBM.movieReviews.model.CriticaDTO;

import java.util.List;

public interface ICriticaService
{
    Critica getById(Integer id);
    List<Critica> getCriticas();
    List<Critica> getByPelicula(Integer peliculaId);
    List<Critica> getByUser(Integer userId);
    Critica publishCritica(String username, CriticaDTO dto, Integer peliculaId);
    void delete(Integer id);
}
