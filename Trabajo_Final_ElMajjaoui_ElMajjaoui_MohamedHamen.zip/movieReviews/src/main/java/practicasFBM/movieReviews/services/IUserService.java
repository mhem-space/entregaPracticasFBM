package practicasFBM.movieReviews.services;

import org.springframework.data.domain.Page;
import practicasFBM.movieReviews.model.User;

import java.util.List;

public interface IUserService
{
    User getById(Integer id);
    User getByUsername(String username);
    List<User> getAll();
    Page<User> getPage(int page, int size);
    User createOrUpdate(User u);
    void delete(Integer id);
}
