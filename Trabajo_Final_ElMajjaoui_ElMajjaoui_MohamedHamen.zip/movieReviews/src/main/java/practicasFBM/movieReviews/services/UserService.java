package practicasFBM.movieReviews.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import practicasFBM.movieReviews.model.User;
import practicasFBM.movieReviews.repository.IUserRepository;

import java.util.List;

@Service
public class UserService implements IUserService
{
    @Autowired
    private IUserRepository repo;

    @Override
    public User getById(Integer id) {
        return repo.getUserById(id);
    }

    @Override
    public User getByUsername(String username) {
        return repo.getUserByUsername(username);
    }

    @Override
    public List<User> getAll() {
        return repo.getAllUsers();
    }

    @Override
    public Page<User> getPage(int page, int size) {
        return repo.getUsersPage(page, size);
    }

    @Override
    public User createOrUpdate(User u) {
        repo.saveUser(u);
        return u;
    }

    @Override
    public void delete(Integer id) {
        repo.deleteUser(id);
    }
}
