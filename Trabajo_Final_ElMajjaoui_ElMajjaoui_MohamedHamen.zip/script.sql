-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: moviesdb
-- ------------------------------------------------------
-- Server version	8.4.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actor`
--

DROP TABLE IF EXISTS `actor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actor` (
  `id_actor` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `pais_nacimiento` varchar(60) NOT NULL,
  PRIMARY KEY (`id_actor`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actor`
--

LOCK TABLES `actor` WRITE;
/*!40000 ALTER TABLE `actor` DISABLE KEYS */;
INSERT INTO `actor` VALUES (1,'Marlon Brando','1924-04-03','Estados Unidos'),(3,'James Caan','1940-03-26','Estados Unidos'),(4,'Robert Duvall','1931-01-28','Estados Unidos'),(5,'Diane Keaton','1943-01-05','Estados Unidos'),(6,'John Marley','1909-11-20','Estados Unidos'),(7,'Richard Castellano','1933-09-24','Estados Unidos'),(8,'Al Lettieri','1935-01-08','Estados Unidos'),(9,'Richard Conte','1910-03-22','Estados Unidos'),(10,'Elijah Wood','1981-01-28','Estados Unidos'),(11,'Ian McKellen','1939-05-25','Inglaterra'),(12,'Liv Tyler','1977-07-17','Estados Unidos'),(13,'Viggo Mortensen','1958-10-20','Estados Unidos'),(14,'Sean Astin','1971-02-25','Estados Unidos'),(15,'Orlando Bloom','1977-01-13','Inglaterra'),(16,'John Rhys-Davies','1944-05-20','Gales'),(17,'Bernard Hill','1944-11-01','Inglaterra'),(18,'Christopher Lee','1922-05-27','Inglaterra'),(22,'Dominic Monaghan','1976-12-08','Inglaterra'),(23,'Billy Boyd','1971-08-28','Escocia'),(25,'Hugo Weaving','1960-04-20','Australia'),(26,'David Wenham','1965-08-21','Australia'),(27,'Andy Serkis','1964-04-20','Inglaterra'),(28,'Sean Bean','1959-04-17','Inglaterra'),(29,'Miranda Otto','1967-01-10','Australia'),(30,'John Noble','1948-06-06','Australia'),(31,'Karl Urban','1972-06-26','Nueva Zelanda'),(32,'Roberto Benigni','1952-03-27','Italia'),(33,'Nicoletta Braschi','1960-04-29','Italia'),(34,'Giorgio Cantarini','1992-05-29','Italia'),(35,'Giustino Durano','1927-02-08','Italia'),(36,'Song Kang-ho','1967-01-17','Corea del Sur'),(37,'Lee Sun-kyun','1974-07-01','Corea del Sur'),(38,'Cho Yeo-jeong','1981-07-15','Corea del Sur'),(39,'Choi Woo-shik','1986-03-26','Corea del Sur'),(40,'Park So-dam','1991-09-10','Corea del Sur'),(41,'Jodie Foster','1962-11-19','Estados Unidos'),(42,'Anthony Hopkins','1937-12-31','Inglaterra'),(43,'Scott Glenn','1941-07-29','Estados Unidos'),(44,'Ted Levine','1940-05-20','Estados Unidos'),(45,'Anthony Heald','1944-02-25','Estados Unidos'),(46,'Kasi Lemmons','1961-03-13','Estados Unidos'),(47,'Benedict Cumberbatch','1976-07-19','Inglaterra'),(48,'Kirsten Dunst','1982-04-30','Estados Unidos'),(49,'Jesse Plemons','1988-01-27','Estados Unidos'),(50,'Kodi Smit-McPhee','2000-06-13','Australia'),(51,'Thomasin McKenzie','2000-07-10','Nueva Zelanda'),(52,'Kerry Condon','1973-01-31','Irlanda del Norte'),(53,'Hidetoshi Nishijima','1971-10-22','Japón'),(54,'Toko Miura','1990-02-19','Japón'),(55,'Reika Kirishima','1981-07-25','Japón'),(56,'Takahide Higuchi','1972-05-27','Japón'),(57,'Masaki Okada','1984-04-16','Japón'),(58,'Yui Natsukawa','1970-02-27','Japón'),(59,'Bradley Cooper','1975-01-05','Estados Unidos'),(60,'Cate Blanchett','1969-05-14','Australia'),(61,'Toni Collette','1972-11-10','Australia'),(62,'Willem Dafoe','1955-07-02','Estados Unidos'),(63,'Richard Jenkins','1947-09-04','Estados Unidos'),(64,'Rooney Mara','1985-04-01','Estados Unidos'),(65,'Ron Perlman','1950-04-13','Estados Unidos'),(66,'David Strathairn','1949-05-26','Estados Unidos'),(67,'Tom Cruise','1962-07-31','Estados Unidos'),(68,'Miles Teller','1986-12-20','Estados Unidos'),(69,'Jennifer Connelly','1970-02-12','Estados Unidos'),(70,'Jon Hamm','1971-03-10','Estados Unidos'),(71,'Glen Powell','1988-01-20','Estados Unidos'),(72,'Lewis Pullman','1993-01-29','Estados Unidos'),(73,'Ed Harris','1950-01-28','Estados Unidos'),(74,'Austin Butler','1991-08-19','Australia'),(75,'Tom Hanks','1956-07-09','Estados Unidos'),(76,'Olivia DeJonge','1998-04-01','Australia'),(77,'Helen Thomson','1967-03-25','Australia'),(78,'Richard Roxburgh','1954-07-21','Australia'),(79,'Kelvin Harrison Jr.','1994-07-23','Estados Unidos'),(80,'Dacre Montgomery','1994-11-22','Australia'),(81,'Yola','1963-07-16','Estados Unidos'),(82,'Luke Bracey','1989-07-26','Australia'),(83,'Jordi Pujol Dolcet','2008-08-20','España'),(84,'Anna Otín','2007-07-12','España'),(85,'Xenia Roset','2006-06-08','España'),(86,'Albert Bosch','2005-05-04','España'),(87,'Ainet Jounou','2004-04-02','España'),(88,'Josep Abad','2003-03-01','España'),(89,'Montse Oró','1975-02-22','España'),(90,'Carles Cabós','1973-01-21','España'),(91,'Berta Pipó','1972-01-20','España'),(92,'Paul Mescal','1991-08-19','Irlanda'),(93,'Frankie Corio','2009-09-22','Reino Unido'),(94,'Celia Rowlson-Hall','1986-03-06','Reino Unido'),(96,'Al Pacino','1940-04-25','Estados Unidos');
/*!40000 ALTER TABLE `actor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authorities`
--

DROP TABLE IF EXISTS `authorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorities` (
  `id_authority` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id_authority`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authorities`
--

LOCK TABLES `authorities` WRITE;
/*!40000 ALTER TABLE `authorities` DISABLE KEYS */;
INSERT INTO `authorities` VALUES (1,'ROLE_ADMIN'),(2,'ROLE_USER');
/*!40000 ALTER TABLE `authorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `critica`
--

DROP TABLE IF EXISTS `critica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `critica` (
  `id_critica` int NOT NULL AUTO_INCREMENT,
  `id_pelicula` int NOT NULL,
  `valoracion` text,
  `nota` int DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id_critica`),
  KEY `fk_critica_pelicula` (`id_pelicula`),
  KEY `fk_critica_user` (`user_id`),
  CONSTRAINT `fk_critica_pelicula` FOREIGN KEY (`id_pelicula`) REFERENCES `pelicula` (`id_pelicula`) ON DELETE CASCADE,
  CONSTRAINT `fk_critica_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id_user`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `critica`
--

LOCK TABLES `critica` WRITE;
/*!40000 ALTER TABLE `critica` DISABLE KEYS */;
INSERT INTO `critica` VALUES (1,1,'dfasdfsadfasdfasdf',8,'2025-07-13',1),(4,2,'no me gustó tanto',6,'2025-07-13',1),(5,1,'no estuvo mal',6,'2025-07-13',2);
/*!40000 ALTER TABLE `critica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelicula`
--

DROP TABLE IF EXISTS `pelicula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pelicula` (
  `id_pelicula` int NOT NULL AUTO_INCREMENT,
  `titulo` tinytext NOT NULL,
  `anno` int NOT NULL,
  `duracion` int NOT NULL,
  `pais` varchar(60) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `genero` varchar(50) NOT NULL,
  `sinopsis` mediumtext NOT NULL,
  `nombre_portada` varchar(255) NOT NULL,
  PRIMARY KEY (`id_pelicula`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelicula`
--

LOCK TABLES `pelicula` WRITE;
/*!40000 ALTER TABLE `pelicula` DISABLE KEYS */;
INSERT INTO `pelicula` VALUES (1,'El padrino',1972,175,'Estados Unidos','Francis Ford Coppola','Gángster','La historia de la familia Corleone, un clan de la mafia de Nueva York, y su patriarca, Vito Corleone, un hombre de negocios respetado pero despiadado.','1.jpg'),(2,'El señor de los anillos: La comunidad del anillo',2001,178,'Nueva Zelanda','Peter Jackson','Fantasía épica','Un hobbit llamado Frodo debe destruir el Anillo Único, una poderosa arma creada por el Señor Oscuro Sauron.','2.jpg'),(3,'El señor de los anillos: Las dos torres',2002,251,'Nueva Zelanda','Peter Jackson','Fantasía épica','Frodo y su grupo de compañeros continúan su viaje para destruir el Anillo Único, mientras que Sauron envía sus fuerzas para detenerlos.','3.jpg'),(4,'El señor de los anillos: El retorno del rey',2003,201,'Nueva Zelanda','Peter Jackson','Fantasía épica','Frodo y su grupo de compañeros llegan a Mordor para destruir el Anillo Único, mientras que Sauron lanza un ataque final contra la Tierra Media.','4.jpg'),(5,'La vida es bella',1997,117,'Italia','Roberto Benigni','Drama','Guido Orefice, un hombre judío, y su hijo Giosuè, tratan de sobrevivir a la ocupación nazi de Italia durante la Segunda Guerra Mundial.','5.jpg'),(6,'Parásitos',2019,132,'Corea del Sur','Bong Joon-ho','Thriller','La familia Kim, una familia pobre, se infiltra en la casa de la familia Park, una familia rica, para aprovecharse de ellos.','6.jpg'),(7,'El silencio de los corderos',1991,118,'Estados Unidos','Jonathan Demme','Thriller','Clarice Starling, una joven agente del FBI, es enviada a entrevistar a Hannibal Lecter, un asesino en serie encarcelado, para obtener información sobre otro asesino en serie.','7.jpg'),(8,'El poder del perro',2021,128,'Estados Unidos','Jane Campion','Drama','La historia de dos hermanos rancheros, Phil y George Burbank, y de la joven viuda que se casa con uno de ellos.','8.jpg'),(9,'Drive My Car',2021,179,'Japón','Ryūsuke Hamaguchi','Drama','Un actor y director de teatro viudo se embarca en un viaje de dos días en un coche con una joven chófer.','9.jpg'),(10,'El callejón de las almas perdidas',2021,150,'Estados Unidos','Guillermo del Toro','Thriller','Un estafador busca a una mujer desaparecida en un mundo de magia y engaño.','10.jpg'),(11,'Top Gun: Maverick',2022,131,'Estados Unidos','Joseph Kosinski','Acción','Pete \"Maverick\" Mitchell, un piloto de pruebas de la Marina de los Estados Unidos, es enviado a entrenar a un grupo de jóvenes pilotos para una misión peligrosa.','11.jpg'),(12,'Elvis',2022,159,'Estados Unidos','Baz Luhrmann','Biopic','La vida y la música de Elvis Presley, desde sus humildes comienzos hasta su ascenso a la fama y su caída en desgracia.','12.jpg'),(13,'Alcarràs',2022,125,'España','Carla Simón','Drama','Una familia de agricultores de melocotones se enfrenta a la última temporada de cosecha en su granja familiar.','13.jpg'),(14,'Aftersun',2022,106,'Reino Unido','Charlotte Wells','Drama','Un niño de 11 años pasa sus vacaciones de verano en Turquía con su madre.','14.jpg'),(16,'prueba',1234,123,'islandia','Francis Ford Coppola','Gángster','La historia de la familia Corleone, un clan de la mafia de Nueva York, y su patriarca, Vito Corleone, un hombre de negocios respetado pero despiadado.','default.jpg');
/*!40000 ALTER TABLE `pelicula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reparto`
--

DROP TABLE IF EXISTS `reparto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reparto` (
  `pelicula_id_pelicula` int NOT NULL,
  `actor_id_actor` int NOT NULL,
  PRIMARY KEY (`pelicula_id_pelicula`,`actor_id_actor`),
  KEY `fk_pelicula_has_actor_actor1_idx` (`actor_id_actor`),
  KEY `fk_pelicula_has_actor_pelicula_idx` (`pelicula_id_pelicula`),
  CONSTRAINT `fk_pelicula_has_actor_actor1` FOREIGN KEY (`actor_id_actor`) REFERENCES `actor` (`id_actor`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_pelicula_has_actor_pelicula` FOREIGN KEY (`pelicula_id_pelicula`) REFERENCES `pelicula` (`id_pelicula`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reparto`
--

LOCK TABLES `reparto` WRITE;
/*!40000 ALTER TABLE `reparto` DISABLE KEYS */;
INSERT INTO `reparto` VALUES (1,1),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(2,10),(3,10),(4,10),(2,11),(3,11),(4,11),(2,12),(2,13),(3,13),(4,13),(2,14),(3,14),(4,14),(2,15),(3,15),(4,15),(2,16),(3,16),(4,16),(3,17),(4,17),(3,18),(4,18),(3,22),(4,22),(3,23),(4,23),(3,25),(4,25),(3,26),(4,26),(3,27),(4,27),(4,28),(4,29),(4,30),(4,31),(5,32),(5,33),(5,34),(5,35),(6,36),(6,37),(6,38),(6,39),(6,40),(7,41),(7,42),(7,43),(7,44),(7,45),(7,46),(8,47),(8,48),(8,49),(8,50),(8,51),(8,52),(9,53),(9,54),(9,55),(9,56),(9,57),(9,58),(10,59),(10,60),(10,61),(10,62),(10,63),(10,64),(10,65),(10,66),(11,67),(11,68),(11,69),(11,70),(11,71),(11,72),(11,73),(12,74),(12,75),(12,76),(12,77),(12,78),(12,79),(12,80),(12,81),(12,82),(13,83),(13,84),(13,85),(13,86),(13,87),(13,88),(13,89),(13,90),(13,91),(14,92),(14,93),(14,94),(1,96);
/*!40000 ALTER TABLE `reparto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin',1),(2,'user','user',1),(3,'prueba1','prueba1',1),(4,'prueba2','prueba2',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_authorities`
--

DROP TABLE IF EXISTS `users_authorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_authorities` (
  `user_id` int NOT NULL,
  `authority_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`authority_id`),
  KEY `authority_id` (`authority_id`),
  CONSTRAINT `users_authorities_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id_user`) ON DELETE CASCADE,
  CONSTRAINT `users_authorities_ibfk_2` FOREIGN KEY (`authority_id`) REFERENCES `authorities` (`id_authority`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_authorities`
--

LOCK TABLES `users_authorities` WRITE;
/*!40000 ALTER TABLE `users_authorities` DISABLE KEYS */;
INSERT INTO `users_authorities` VALUES (1,1),(2,2),(3,2),(4,2);
/*!40000 ALTER TABLE `users_authorities` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-14  0:07:04
