package practicasFBM.movieFiles.repository;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import practicasFBM.movieFiles.model.Actor;
import practicasFBM.movieFiles.model.Pelicula;

import java.util.List;
import java.util.Optional;

@Repository
public class ActorRepository implements IActorRepository
{
    @Autowired
    IActorJPA actorJPA;

    @Override
    public Actor getActorById(Integer idActor)
    {
        Optional<Actor> actor = actorJPA.findById(idActor);
        return actor.orElse(null);
    }

    @Override
    public List<Pelicula> getParticipaciones(Integer idActor)
    {
        Actor actor = getActorById(idActor);
        if (actor!= null)
        {
            return actor.getPeliculas();
        }
        return null;
    }

    @Override
    public void eliminarActor(Integer idActor)
    {
        actorJPA.deleteById(idActor);
    }

    @Override
    public List<Actor> getActores()
    {
        return actorJPA.findAll();
    }

    @Override
    public void guardarActor(Actor actorNuevo)
    {
        actorJPA.save(actorNuevo);
    }

    @Override
    public void actualizarActor(Actor actorActualizado)
    {
        Actor actor = getActorById(actorActualizado.getIdActor());
        if (actor!=null)
        {
            actor.setNombre(actorActualizado.getNombre());
            actor.setFechaNacimiento(actorActualizado.getFechaNacimiento());
            actor.setPaisNacimiento(actorActualizado.getPaisNacimiento());
            actorJPA.save(actor);
        }
    }
}
