package practicasFBM.movieFiles.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import practicasFBM.movieFiles.model.Actor;

public interface IActorJPA extends JpaRepository<Actor, Integer>
{
}
