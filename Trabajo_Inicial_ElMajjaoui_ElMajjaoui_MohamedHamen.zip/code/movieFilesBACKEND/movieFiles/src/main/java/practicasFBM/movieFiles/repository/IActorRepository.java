package practicasFBM.movieFiles.repository;

import practicasFBM.movieFiles.model.Actor;
import practicasFBM.movieFiles.model.Pelicula;

import java.util.List;


public interface IActorRepository
{
    Actor getActorById(Integer idActor);

    List<Pelicula> getParticipaciones(Integer idActor);

    void eliminarActor(Integer idActor);

    List<Actor> getActores();

    void guardarActor(Actor actorNuevo);

    void actualizarActor(Actor actorActualizado);
}
