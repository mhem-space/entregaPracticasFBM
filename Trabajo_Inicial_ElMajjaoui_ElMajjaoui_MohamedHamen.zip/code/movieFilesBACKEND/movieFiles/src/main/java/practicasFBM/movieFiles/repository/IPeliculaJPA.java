package practicasFBM.movieFiles.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import practicasFBM.movieFiles.model.Pelicula;

import java.util.List;

public interface IPeliculaJPA extends JpaRepository<Pelicula, Integer>
{
    Page<Pelicula> findByTituloContainingIgnoreCase(String titulo, Pageable pageable);
    Page<Pelicula> findByGeneroContainingIgnoreCase(String genero, Pageable pageable);

    @Query("SELECT DISTINCT p FROM Pelicula p " +
            "INNER JOIN p.actors a " +
            "WHERE a.nombre = ?1")
    Page<Pelicula> getPeliculasByActor(String nombreActor, Pageable pageable);

    Page<Pelicula> findAll(Pageable pageable);
}
