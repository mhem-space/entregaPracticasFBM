package practicasFBM.movieFiles.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Repository;
import practicasFBM.movieFiles.model.Actor;
import practicasFBM.movieFiles.model.Pelicula;

import java.util.List;
import java.util.Optional;

@Repository
public class PeliculaRepository implements IPeliculaRepository
{
    @Autowired
    IPeliculaJPA peliculaJPA;

    @Override
    public Pelicula getPeliculaById(Integer idPelicula)
    {
        Optional<Pelicula> pelicula = peliculaJPA.findById(idPelicula);
        return pelicula.orElse(null);
    }

    @Override
    public List<Actor> getReparto(Integer idPelicula)
    {
        Pelicula pelicula = getPeliculaById(idPelicula);
        if (pelicula!= null)
        {
            return pelicula.getActors();
        }
        return null;
    }

    @Override
    public void eliminarPelicula(Integer idPelicula)
    {
        peliculaJPA.deleteById(idPelicula);
    }

//    @Override
//    public List<Pelicula> getPeliculas()
//    {
//        return peliculaJPA.findAll();
//    }

    @Override
    public Page<Pelicula> getPeliculasPaginadas(int page, int size) {
        return peliculaJPA.findAll(PageRequest.of(page, size));
    }

    @Override
    public Page<Pelicula> getPeliculasByTitulo(String titulo, int page, int size)
    {
        return peliculaJPA.findByTituloContainingIgnoreCase(titulo, PageRequest.of(page, size));
    }

    @Override
    public Page<Pelicula> getPeliculasByGenero(String genero, int page, int size)
    {
        return peliculaJPA.findByGeneroContainingIgnoreCase(genero, PageRequest.of(page, size));
    }

    @Override
    public Page<Pelicula> getPeliculasByActor(String nombreActor, int page, int size)
    {
        return peliculaJPA.getPeliculasByActor(nombreActor, PageRequest.of(page, size));
    }

    @Override
    public void guardarPelicula(Pelicula peliculaNueva)
    {
        peliculaJPA.save(peliculaNueva);
    }

    @Override
    public void actualizarPelicula(Pelicula peliculaActualizada)
    {
        Pelicula pelicula = getPeliculaById(peliculaActualizada.getIdPelicula());
        if (pelicula!=null)
        {
            pelicula.setTitulo(peliculaActualizada.getTitulo());
            pelicula.setAnno(peliculaActualizada.getAnno());
            pelicula.setDuracion(peliculaActualizada.getDuracion());
            pelicula.setPais(peliculaActualizada.getPais());
            pelicula.setDireccion(peliculaActualizada.getDireccion());
            pelicula.setGenero(peliculaActualizada.getGenero());
            pelicula.setSinopsis(peliculaActualizada.getSinopsis());
            if (peliculaActualizada.getActors() != null) {
                pelicula.setActors(peliculaActualizada.getActors());
            }
            if (peliculaActualizada.getNombrePortada() != null) {
                pelicula.setNombrePortada(peliculaActualizada.getNombrePortada());
            }
            peliculaJPA.save(pelicula);
        }
    }

}
