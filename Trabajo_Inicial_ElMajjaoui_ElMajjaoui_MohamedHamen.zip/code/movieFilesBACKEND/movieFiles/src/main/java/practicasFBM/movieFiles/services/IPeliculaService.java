package practicasFBM.movieFiles.services;

import org.springframework.data.domain.Page;
import org.springframework.web.multipart.MultipartFile;
import practicasFBM.movieFiles.model.Actor;
import practicasFBM.movieFiles.model.Pelicula;

import java.io.IOException;
import java.util.List;

public interface IPeliculaService
{
    Pelicula getPeliculaById(Integer idPelicula);

    List<Actor> getReparto(Integer idPelicula);

    void eliminarPelicula(Integer idPelicula);

//    List<Pelicula> getPeliculas();
    Page<Pelicula> getPeliculasPaginadas(int page, int size);

    Page<Pelicula> getPeliculasByTitulo(String titulo, int page, int size);

    Page<Pelicula> getPeliculasByGenero(String genero, int page, int size);

    Page<Pelicula> getPeliculasByActor(String nombreActor, int page, int size);

    void guardarPelicula(Pelicula peliculaNueva);

    void actualizarPelicula(Pelicula peliculaActualizada);
    void guardarPortada(Integer id, MultipartFile file) throws IOException;
    byte[] obtenerPortada(Integer id) throws IOException;
}
