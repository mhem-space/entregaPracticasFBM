package practicasFBM.movieFilesFront.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import practicasFBM.movieFilesFront.Model.Actor;
import practicasFBM.movieFilesFront.Model.Pelicula;
import practicasFBM.movieFilesFront.Paginator.PageRender;
import practicasFBM.movieFilesFront.Services.IActorService;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/actores")
public class ActorController
{
    @Autowired
    IActorService actorService;

    @GetMapping("/gestion")
    public String gestionActores(Model model, @RequestParam Optional<Integer> page) {
        Page<Actor> listadoActores = actorService.getListadoActores(PageRequest.of(page.orElse(0), 10, Sort.Direction.DESC, "idActor"));
        PageRender<Actor> pageRender = new PageRender<Actor>("/actores/gestion", listadoActores);

        model.addAttribute("listadoActores",listadoActores);
        model.addAttribute("page",pageRender);

        return "actor/gestionActores"; // Este es el nombre de tu plantilla Thymeleaf (index.html).
    }

    @GetMapping("/actores")
    @ResponseBody
    public List<Actor> getActores()
    {
        return actorService.getActores();
    }

    @GetMapping("/add")
    public String agregarActor(Model model)
    {
        model.addAttribute("titulo", "Nuevo actor");
        Actor actorNuevo = new Actor();
        model.addAttribute("actor",actorNuevo);
        return "actor/agregarActor";
    }

    @PostMapping("/addActor")
    public String agregarActor(Model model, Actor actorNuevo, RedirectAttributes attributes)
    {
        actorService.guardarActor(actorNuevo);
        model.addAttribute("titulo", "Nuevo actor");
        attributes.addFlashAttribute("msg", "Los datos del nuevo actor han sido guardados!");
        return "redirect:/actores/gestion";
    }

    @GetMapping("/editar/{id}")
    public String editarActor(Model model, @PathVariable("id") Integer id) {
        Actor actor = actorService.getActorById(id);
        model.addAttribute("titulo", "Editar actor");
        model.addAttribute("actor", actor);
        return "actor/editarActor";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarPelicula(Model model, @PathVariable("id") Integer id,RedirectAttributes attributes) {
        actorService.eliminarActor(id);
        attributes.addFlashAttribute("msg", "Los datos del actor han sido eliminados!");
        return "redirect:/actores/gestion";
    }
}
