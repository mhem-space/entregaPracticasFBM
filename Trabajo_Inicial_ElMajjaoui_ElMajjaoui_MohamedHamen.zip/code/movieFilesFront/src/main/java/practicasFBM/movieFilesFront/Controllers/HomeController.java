package practicasFBM.movieFilesFront.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import practicasFBM.movieFilesFront.Model.Pelicula;
import practicasFBM.movieFilesFront.Paginator.PageRender;
import practicasFBM.movieFilesFront.Services.IActorService;
import practicasFBM.movieFilesFront.Services.IPeliculaService;

import java.util.Optional;

@Controller
public class HomeController
{
    @Autowired
    IPeliculaService peliculaService;
    @Autowired
    IActorService service;

    @GetMapping("/")
    public String home() {
        return "home"; // Este es el nombre de tu plantilla Thymeleaf (index.html).
    }

    @GetMapping("/principal")
    public String movieFiles(Model model, @RequestParam Optional<Integer> page,
                             @RequestParam(name = "filtro", required = false) String filtro,
                             @RequestParam(name = "busqueda", required = false) String busqueda) {

        int pageNumber = page.orElse(0);
        Page<Pelicula> listadoPeliculas;

        if (busqueda != null && !busqueda.isEmpty()) {
            if ("genero".equalsIgnoreCase(filtro)) {
                listadoPeliculas = peliculaService.getPeliculasByGenero(PageRequest.of(pageNumber, 8, Sort.Direction.ASC, "idPelicula"), busqueda);
            } else if ("actor".equalsIgnoreCase(filtro)) {
                listadoPeliculas = peliculaService.getPeliculasByActor(PageRequest.of(pageNumber, 8, Sort.Direction.ASC, "idPelicula"), busqueda);
            } else {
                listadoPeliculas = peliculaService.getPeliculasByTitulo(PageRequest.of(pageNumber, 8, Sort.Direction.ASC, "idPelicula"), busqueda);
            }
        } else {
            listadoPeliculas = peliculaService.getPeliculas(PageRequest.of(pageNumber, 8, Sort.Direction.ASC, "idPelicula"));
        }

        String url = "/principal";
        if (busqueda != null && !busqueda.isEmpty()) {
            url += "?filtro=" + filtro + "&busqueda=" + busqueda;
        }

        PageRender<Pelicula> pageRender = new PageRender<Pelicula>(url, listadoPeliculas);

        model.addAttribute("listadoPeliculas", listadoPeliculas);
        model.addAttribute("page", pageRender);
        model.addAttribute("filtro", filtro);
        model.addAttribute("busqueda", busqueda);

        return "movieFiles"; // Este es el nombre de la plantilla Thymeleaf que muestra las películas.
    }

    @GetMapping("/ver/{id}")
    public String verPelicula(Model model, @PathVariable("id") Integer id)
    {
        Pelicula pelicula = peliculaService.getPeliculaById(id);
        pelicula.setActors(peliculaService.getReparto(id));

        model.addAttribute("pelicula",pelicula);

        return "detallesPelicula";  // Este es el nombre de la plantilla Thymeleaf que muestra los detalles de la película.
    }
}
