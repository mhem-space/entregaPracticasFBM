package practicasFBM.movieFilesFront.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "actor", schema = "moviesdb")
public class Actor
{
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_actor")
    private Integer idActor;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "fecha_nacimiento")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate fechaNacimiento;
    @Basic
    @Column(name = "pais_nacimiento")
    private String paisNacimiento;

    @ManyToMany(mappedBy = "actors")
    @JsonIgnore
    private List<Pelicula> reparto = new ArrayList<>();

    public List<Pelicula> getReparto()
    {
        return reparto;
    }

    public void setReparto(List<Pelicula> reparto)
    {
        this.reparto = reparto;
    }

    public Integer getIdActor()
    {
        return idActor;
    }

    public void setIdActor(Integer idActor)
    {
        this.idActor = idActor;
    }

    public String getNombre()
    {
        return nombre;
    }

    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }

    public LocalDate getFechaNacimiento()
    {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento)
    {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getPaisNacimiento()
    {
        return paisNacimiento;
    }

    public void setPaisNacimiento(String paisNacimiento)
    {
        this.paisNacimiento = paisNacimiento;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Actor that = (Actor) o;
        return Objects.equals(idActor, that.idActor) && Objects.equals(nombre, that.nombre) && Objects.equals(fechaNacimiento, that.fechaNacimiento) && Objects.equals(paisNacimiento, that.paisNacimiento);
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(idActor, nombre, fechaNacimiento, paisNacimiento);
    }
}
