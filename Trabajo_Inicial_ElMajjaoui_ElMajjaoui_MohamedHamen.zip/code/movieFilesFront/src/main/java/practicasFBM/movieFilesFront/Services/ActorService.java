package practicasFBM.movieFilesFront.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import practicasFBM.movieFilesFront.Model.Actor;
import practicasFBM.movieFilesFront.Model.Pelicula;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class ActorService implements IActorService
{
    @Autowired
    RestTemplate template;
    String url = "http://localhost:8002/actores";

    @Override
    public List<Actor> getActores()
    {
        Actor[] actores = template.getForObject(url, Actor[].class);

        return actores != null ? Arrays.asList(actores) : null;
    }

    public Page<Actor> getListadoActores(Pageable pageable)
    {
        // Utiliza la clase UriComponentsBuilder para construir la URL de manera segura
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url).queryParam("page", pageable.getPageNumber());
        URI uri = builder.build().toUri();

        Actor[] actores = template.getForObject(uri, Actor[].class);
        List<Actor> listadoActores = Arrays.asList(actores);

        int pageSize = pageable.getPageSize();
        int currentPage = pageable.getPageNumber();
        int startItem = currentPage*pageSize;
        List<Actor> list;

        if (listadoActores.size() < startItem)
        {
            list = Collections.emptyList();
        }
        else
        {
            int toIndex = Math.min(startItem + pageSize, listadoActores.size());
            list = listadoActores.subList(startItem, toIndex);
        }

        return new PageImpl<>(list, PageRequest.of(currentPage, pageSize), listadoActores.size());
    }

    @Override
    public Actor getActorById(Integer idActor)
    {
        return template.getForObject(url+"/"+idActor, Actor.class);
    }

    @Override
    public List<Pelicula> getParticipaciones(Integer idActor)
    {
        return null;
    }

    @Override
    public void eliminarActor(Integer idActor)
    {
        template.delete(url + "/eliminar/" + idActor);
    }

    @Override
    public void guardarActor(Actor actorNuevo)
    {
        if (actorNuevo.getIdActor() != null)
        {
            template.put(url, actorNuevo);
        }
        else
        {
            template.postForObject(url,actorNuevo, String.class);
        }
    }

}
