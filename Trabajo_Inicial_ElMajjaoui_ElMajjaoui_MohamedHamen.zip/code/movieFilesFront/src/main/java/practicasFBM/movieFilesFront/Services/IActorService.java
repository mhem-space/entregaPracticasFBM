package practicasFBM.movieFilesFront.Services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import practicasFBM.movieFilesFront.Model.Actor;
import practicasFBM.movieFilesFront.Model.Pelicula;

import java.util.List;

public interface IActorService
{
    Actor getActorById(Integer idActor);

    List<Pelicula> getParticipaciones(Integer idActor);

    void eliminarActor(Integer idActor);

    List<Actor> getActores();

    Page<Actor> getListadoActores(Pageable pageable);

    void guardarActor(Actor actorNuevo);

}
