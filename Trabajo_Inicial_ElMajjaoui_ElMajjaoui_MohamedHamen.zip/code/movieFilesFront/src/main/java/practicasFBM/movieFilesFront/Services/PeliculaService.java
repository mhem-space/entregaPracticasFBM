package practicasFBM.movieFilesFront.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;
import practicasFBM.movieFilesFront.Model.Actor;
import practicasFBM.movieFilesFront.Model.Pelicula;
import practicasFBM.movieFilesFront.Model.PageResponse;

import java.io.IOException;
import java.net.URI;
import java.util.*;

@Service
public class PeliculaService implements IPeliculaService
{
    @Autowired
    RestTemplate template;

    @Autowired
    IActorService actorService;

    String url = "http://localhost:8002/peliculas";

    @Override
    public Page<Pelicula> getPeliculas(Pageable pageable)
    {
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url)
            .queryParam("page", pageable.getPageNumber())
            .queryParam("size", pageable.getPageSize());
        URI uri = builder.build().toUri();

        ResponseEntity<PageResponse<Pelicula>> response = template.exchange(
            uri,
            HttpMethod.GET,
            null,
            new ParameterizedTypeReference<PageResponse<Pelicula>>() {}
        );
        PageResponse<Pelicula> pageResponse = response.getBody();
        List<Pelicula> listadoPeliculas = pageResponse != null ? pageResponse.getContent() : Collections.emptyList();

        // Si necesitas devolver un Page<Pelicula>, puedes usar PageImpl
        return new PageImpl<>(listadoPeliculas, pageable, pageResponse != null ? pageResponse.getTotalElements() : 0);
    }

    @Override
    public Pelicula getPeliculaById(Integer idPelicula)
    {
        Pelicula pelicula = template.getForObject(url+"/"+idPelicula, Pelicula.class);
        List<Integer> listaActores = new ArrayList<>();
        for (Actor actor:pelicula.getActors())
        {
            listaActores.add(actor.getIdActor());
        }
        pelicula.setListaActores(listaActores);

        return pelicula;
    }

    @Override
    public List<Actor> getReparto(Integer idPelicula)
    {
        Actor[] actores = template.getForObject(url+"/reparto/"+idPelicula, Actor[].class);

        return actores != null ? Arrays.asList(actores) : null;
    }

    @Override
    public void eliminarPelicula(Integer idPelicula)
    {
        template.delete(url + "/eliminar/" + idPelicula);
    }

    @Override
    public Page<Pelicula> getPeliculasByTitulo(Pageable pageable, String titulo)
    {
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url + "/titulo")
                .queryParam("titulo", titulo)
                .queryParam("page", pageable.getPageNumber())
                .queryParam("size", pageable.getPageSize());
        URI uri = builder.build().toUri();

        ResponseEntity<PageResponse<Pelicula>> response = template.exchange(
                uri,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<PageResponse<Pelicula>>() {}
        );
        PageResponse<Pelicula> pageResponse = response.getBody();
        List<Pelicula> listadoPeliculas = pageResponse != null ? pageResponse.getContent() : Collections.emptyList();

        return new PageImpl<>(listadoPeliculas, pageable, pageResponse != null ? pageResponse.getTotalElements() : 0);
    }

    @Override
    public Page<Pelicula> getPeliculasByGenero(Pageable pageable, String genero)
    {
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url + "/genero")
                .queryParam("genero", genero)
                .queryParam("page", pageable.getPageNumber())
                .queryParam("size", pageable.getPageSize());
        URI uri = builder.build().toUri();

        ResponseEntity<PageResponse<Pelicula>> response = template.exchange(
                uri,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<PageResponse<Pelicula>>() {}
        );
        PageResponse<Pelicula> pageResponse = response.getBody();
        List<Pelicula> listadoPeliculas = pageResponse != null ? pageResponse.getContent() : Collections.emptyList();

        return new PageImpl<>(listadoPeliculas, pageable, pageResponse != null ? pageResponse.getTotalElements() : 0);
    }

    @Override
    public Page<Pelicula> getPeliculasByActor(Pageable pageable, String nombreActor)
    {
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url + "/nombreActor")
                .queryParam("nombreActor", nombreActor)
                .queryParam("page", pageable.getPageNumber())
                .queryParam("size", pageable.getPageSize());
        URI uri = builder.build().toUri();

        ResponseEntity<PageResponse<Pelicula>> response = template.exchange(
                uri,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<PageResponse<Pelicula>>() {}
        );
        PageResponse<Pelicula> pageResponse = response.getBody();
        List<Pelicula> listadoPeliculas = pageResponse != null ? pageResponse.getContent() : Collections.emptyList();

        return new PageImpl<>(listadoPeliculas, pageable, pageResponse != null ? pageResponse.getTotalElements() : 0);
    }

    @Override
    public void guardarPelicula(Pelicula peliculaNueva)
    {
        List<Integer> actoresSeleccionados = peliculaNueva.getListaActores();
        List<Actor> actores = new ArrayList<>();

        for (Integer idActor: actoresSeleccionados)
        {
            actores.add(actorService.getActorById(idActor));
        }

        if (peliculaNueva.getIdPelicula() != null)
        {
            peliculaNueva.setActors(actores);
            template.put(url, peliculaNueva);
        }
        else
        {
            peliculaNueva.setActors(actores);
            template.postForObject(url,peliculaNueva, String.class);
        }

    }

    @Override
    public Pelicula crearPelicula(Pelicula pelicula) {
        return template.postForObject(
                url,
                pelicula,
                Pelicula.class
        );
    }

    @Override
    public void subirPortada(Integer idPelicula, MultipartFile file) throws IOException
    {
        // 1) Nombre: {id}.{ext}
        String ext = StringUtils.getFilenameExtension(file.getOriginalFilename());
        String nombreArchivo = file.getOriginalFilename();

        // 2) Prepara el recurso como ByteArrayResource
        ByteArrayResource recurso = new ByteArrayResource(file.getBytes()) {
            @Override public String getFilename() { return nombreArchivo; }
        };

        // 3) Crea el cuerpo multipart
        MultiValueMap<String,Object> cuerpo = new LinkedMultiValueMap<>();
        cuerpo.add("file", recurso);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        HttpEntity<MultiValueMap<String,Object>> peticion =
                new HttpEntity<>(cuerpo, headers);

        template.postForEntity(
                url + "/" + idPelicula + "/portada",
                peticion,
                Void.class
        );
    }
}
