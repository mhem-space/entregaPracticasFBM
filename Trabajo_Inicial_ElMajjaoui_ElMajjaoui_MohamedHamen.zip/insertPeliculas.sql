INSERT INTO `moviesdb`.`pelicula` (
  `titulo`,
  `anno`,
  `duracion`,
  `pais`,
  `direccion`,
  `genero`,
  `sinopsis`,
  `portada`
) VALUES
(
  'El padrino',
  1972,
  175,
  'Estados Unidos',
  'Francis Ford Coppola',
  'Gángster',
  'La historia de la familia Corleone, un clan de la mafia de Nueva York, y su patriarca, Vito Corleone, un hombre de negocios respetado pero despiadado.',
  '1.png'
),
(
  'El señor de los anillos: La comunidad del anillo',
  2001,
  178,
  'Nueva Zelanda',
  'Peter Jackson',
  'Fantasía épica',
  'Un hobbit llamado Frodo debe destruir el Anillo Único, una poderosa arma creada por el Señor Oscuro Sauron.',
  '2.png'
),
(
  'El señor de los anillos: Las dos torres',
  2002,
  251,
  'Nueva Zelanda',
  'Peter Jackson',
  'Fantasía épica',
  'Frodo y su grupo de compañeros continúan su viaje para destruir el Anillo Único, mientras que Sauron envía sus fuerzas para detenerlos.',
  '3.png'
),
(
  'El señor de los anillos: El retorno del rey',
  2003,
  201,
  'Nueva Zelanda',
  'Peter Jackson',
  'Fantasía épica',
  'Frodo y su grupo de compañeros llegan a Mordor para destruir el Anillo Único, mientras que Sauron lanza un ataque final contra la Tierra Media.',
  '4.png'
),
(
  'La vida es bella',
  1997,
  117,
  'Italia',
  'Roberto Benigni',
  'Drama',
  'Guido Orefice, un hombre judío, y su hijo Giosuè, tratan de sobrevivir a la ocupación nazi de Italia durante la Segunda Guerra Mundial.',
  '5.png'
),
(
  'Parásitos',
  2019,
  132,
  'Corea del Sur',
  'Bong Joon-ho',
  'Thriller',
  'La familia Kim, una familia pobre, se infiltra en la casa de la familia Park, una familia rica, para aprovecharse de ellos.',
  '6.png'
),
(
  'El silencio de los corderos',
  1991,
  118,
  'Estados Unidos',
  'Jonathan Demme',
  'Thriller',
  'Clarice Starling, una joven agente del FBI, es enviada a entrevistar a Hannibal Lecter, un asesino en serie encarcelado, para obtener información sobre otro asesino en serie.',
  '7.png'
),
(
  'El poder del perro',
  2021,
  128,
  'Estados Unidos',
  'Jane Campion',
  'Drama',
  'La historia de dos hermanos rancheros, Phil y George Burbank, y de la joven viuda que se casa con uno de ellos.',
  '8.png'
),
(
  'Drive My Car',
  2021,
  179,
  'Japón',
  'Ryūsuke Hamaguchi',
  'Drama',
  'Un actor y director de teatro viudo se embarca en un viaje de dos días en un coche con una joven chófer.',
  '9.png'
),
(
  'El callejón de las almas perdidas',
  2021,
  150,
  'Estados Unidos',
  'Guillermo del Toro',
  'Thriller',
  'Un estafador busca a una mujer desaparecida en un mundo de magia y engaño.',
  '10.png'
),
(
  'Top Gun: Maverick',
  2022,
  131,
  'Estados Unidos',
  'Joseph Kosinski',
  'Acción',
  'Pete "Maverick" Mitchell, un piloto de pruebas de la Marina de los Estados Unidos, es enviado a entrenar a un grupo de jóvenes pilotos para una misión peligrosa.',
  '11.png'
),
(
  'Elvis',
  2022,
  159,
  'Estados Unidos',
  'Baz Luhrmann',
  'Biopic',
  'La vida y la música de Elvis Presley, desde sus humildes comienzos hasta su ascenso a la fama y su caída en desgracia.',
  '12.png'
),
(
  'Alcarràs',
  2022,
  125,
  'España',
  'Carla Simón',
  'Drama',
  'Una familia de agricultores de melocotones se enfrenta a la última temporada de cosecha en su granja familiar.',
  '13.png'
),
(
  'Aftersun',
  2022,
  106,
  'Reino Unido',
  'Charlotte Wells',
  'Drama',
  'Un niño de 11 años pasa sus vacaciones de verano en Turquía con su madre.',
  '14.png'
);
