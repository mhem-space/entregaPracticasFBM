INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (1, 1);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (1, 96);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (1, 3);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (1, 4);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (1, 5);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (1, 6);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (1, 7);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (1, 8);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (1, 9);

INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (2, 10);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (2, 11);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (2, 12);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (2, 13);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (2, 14);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (2, 15);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (2, 16);

INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 10);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 11);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 13);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 14);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 15);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 16);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 17);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 18);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 22);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 23);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 25);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 26);
INSERT INTO `moviesdb`.`reparto` (`pelicula_id_pelicula`, `actor_id_actor`) VALUES (3, 27);

-- Película 4: El retorno del rey
INSERT INTO `moviesdb`.`reparto` VALUES (4, 10), (4, 11), (4, 13), (4, 14), (4, 15), (4, 16), (4, 17), (4, 18), (4, 22), (4, 23), (4, 25), (4, 26), (4, 27), (4, 28), (4, 29), (4, 30), (4, 31);

-- Película 5: La vida es bella
INSERT INTO `moviesdb`.`reparto` VALUES (5, 32), (5, 33), (5, 34), (5, 35);

-- Película 6: Parásitos
INSERT INTO `moviesdb`.`reparto` VALUES (6, 36), (6, 37), (6, 38), (6, 39), (6, 40);

-- Película 7: El silencio de los corderos
INSERT INTO `moviesdb`.`reparto` VALUES (7, 41), (7, 42), (7, 43), (7, 44), (7, 45), (7, 46);

-- Película 8: El poder del perro
INSERT INTO `moviesdb`.`reparto` VALUES (8, 47), (8, 48), (8, 49), (8, 50), (8, 51), (8, 52);

-- Película 9: Drive My Car
INSERT INTO `moviesdb`.`reparto` VALUES (9, 53), (9, 54), (9, 55), (9, 56), (9, 57), (9, 58);

-- Película 10: El callejón de las almas perdidas
INSERT INTO `moviesdb`.`reparto` VALUES (10, 59), (10, 60), (10, 61), (10, 62), (10, 63), (10, 64), (10, 65), (10, 66);

-- Película 11: Top Gun: Maverick
INSERT INTO `moviesdb`.`reparto` VALUES (11, 67), (11, 68), (11, 69), (11, 70), (11, 71), (11, 72), (11, 73);

-- Película 12: Elvis
INSERT INTO `moviesdb`.`reparto` VALUES (12, 74), (12, 75), (12, 76), (12, 77), (12, 78), (12, 79), (12, 80), (12, 81), (12, 82);

-- Película 13: Alcarràs
INSERT INTO `moviesdb`.`reparto` VALUES (13, 83), (13, 84), (13, 85), (13, 86), (13, 87), (13, 88), (13, 89), (13, 90), (13, 91);

-- Película 14: Aftersun
INSERT INTO `moviesdb`.`reparto` VALUES (14, 92), (14, 93), (14, 94);
