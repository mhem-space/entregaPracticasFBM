SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema moviesdb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema moviesdb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `moviesdb` ;
USE `moviesdb` ;

-- -----------------------------------------------------
-- Table `moviesdb`.`pelicula`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `moviesdb`.`pelicula` (
  `id_pelicula` INT NOT NULL AUTO_INCREMENT,
  `titulo` TINYTEXT NOT NULL,
  `anno` INT NOT NULL,
  `duracion` INT NOT NULL,
  `pais` VARCHAR(60) NOT NULL,
  `direccion` VARCHAR(200) NOT NULL,
  `genero` VARCHAR(50) NOT NULL,
  `sinopsis` MEDIUMTEXT NOT NULL,
  `nombre_portada` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id_pelicula`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `moviesdb`.`actor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `moviesdb`.`actor` (
  `id_actor` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(200) NOT NULL,
  `fecha_nacimiento` DATE NOT NULL,
  `pais_nacimiento` VARCHAR(60) NOT NULL,
  PRIMARY KEY (`id_actor`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `moviesdb`.`reparto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `moviesdb`.`reparto` (
  `pelicula_id_pelicula` INT NOT NULL,
  `actor_id_actor` INT NOT NULL,
  PRIMARY KEY (`pelicula_id_pelicula`, `actor_id_actor`),
  INDEX `fk_pelicula_has_actor_actor1_idx` (`actor_id_actor` ASC) VISIBLE,
  INDEX `fk_pelicula_has_actor_pelicula_idx` (`pelicula_id_pelicula` ASC) VISIBLE,
  CONSTRAINT `fk_pelicula_has_actor_pelicula`
    FOREIGN KEY (`pelicula_id_pelicula`)
    REFERENCES `moviesdb`.`pelicula` (`id_pelicula`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_pelicula_has_actor_actor1`
    FOREIGN KEY (`actor_id_actor`)
    REFERENCES `moviesdb`.`actor` (`id_actor`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
